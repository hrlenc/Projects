// Sample data for products
const products = [
  {
    name: "Ascorbic Acid",
    price: 120,
    originalPrice: null,
    discount: null,
    rating: 4.5,
    image: "logo/pills.jpg"
  },
  {
    name: "Vitamin B Complex",
    price: 240,
    originalPrice: 260,
    discount: "20%",
    rating: 3.5,
    image: "logo/pills.jpg"
  },
  {
    name: "Amlodipine 10mg",
    price: 180,
    originalPrice: null,
    discount: null,
    rating: 4.0,
    image: "logo/pills.jpg"
  },
  {
    name: "Losartan 50mg",
    price: 130,
    originalPrice: 160,
    discount: "30%",
    rating: 4.5,
    image: "logo/pills.jpg"
  }
];

// Function to render products in any specified container
const renderProducts = (containerId) => {
  const container = document.getElementById(containerId);
  products.forEach(product => {
    const card = document.createElement("div");
    card.classList.add("product-card");
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <div class="price">
        $${product.price}
        ${product.originalPrice ? `<span class="original-price">$${product.originalPrice}</span>` : ""}
        ${product.discount ? `<span class="discount">-${product.discount}</span>` : ""}
      </div>
      <div class="rating">⭐ ${product.rating}/5</div>
    `;
    container.appendChild(card);
  });
};

// Initialize products for both sections
window.onload = () => {
  renderProducts("products-container");      // First section
  renderProducts("products-container-2");    // Second section
};

// Select DOM elements for buttons and feedback container
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const feedbackContainer = document.getElementById('feedback-container');

let currentIndex = 0;
const feedbackCards = document.querySelectorAll('.feedback-card');
const cardWidth = feedbackCards[0].offsetWidth + 20; // Card width plus margin

// Hide overflow to remove scrollbar
feedbackContainer.style.overflow = 'hidden';

// Initially position cards side by side using absolute positioning
feedbackCards.forEach((card, index) => {
    card.style.left = `${index * cardWidth}px`; // Position each card horizontally
});

// Function to update the position of the cards
function updateCarousel() {
    feedbackCards.forEach((card, index) => {
        // Move each card using transform to create the sliding effect
        card.style.transform = `translateX(${(index - currentIndex) * cardWidth}px)`;
    });
}

// Scroll to the previous card
prevBtn.addEventListener('click', () => {
    if (currentIndex > 0) {
        currentIndex--; // Decrease the index to move left
        updateCarousel();
    }
});

// Scroll to the next card
nextBtn.addEventListener('click', () => {
    if (currentIndex < feedbackCards.length - 1) {
        currentIndex++; // Increase the index to move right
        updateCarousel();
    }
});


//newsletter
document.getElementById("newsletter-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const emailInput = document.getElementById("email-input");
  const emailValue = emailInput.value;

  if (emailValue.trim() === "") {
    alert("Please enter a valid email address.");
    return;
  }

  alert(`Thank you for subscribing! An email has been sent to ${emailValue}`);
  emailInput.value = ""; // Clear the input field after submission
});